package model;

public enum patient_enum {
    KONNYEN_GYOGYITHATO, GYOGYITHATO, NEHEZEN_GYOGYITHATO, HALAL
}
