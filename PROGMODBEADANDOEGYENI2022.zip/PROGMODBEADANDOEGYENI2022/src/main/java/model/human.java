package model;

public interface human {
    public String getName();
    public void setName(String name);
}
