package com.group.progmodbeadandoegyeni2022.resources;

public class JakartaEE9Resource {

}

